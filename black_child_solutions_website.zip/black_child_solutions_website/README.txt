BLACK CHILD SOLUTIONS FOR ALL — WEBSITE STARTER

Files:
- index.html: responsive company website (open in a browser to preview)

Before publishing:
1. The current Gmail address blackchildstationaryandsupplie@gmail.com has been added to the Contact section and enquiry form. Replace it later if you create a domain-based email address.
2. WhatsApp number +27 60 482 3110 has been added with a direct WhatsApp link. Verify it is the correct business number before publishing.
3. Confirm all service descriptions match the company's actual capabilities, registrations and insurance.
4. Add your verified company registration details only if you want them public.
5. Check and register blackchildsolutions.co.za if it is available. Domain availability has not been verified.

Low-cost publishing:
- GitHub Pages can host a static website at no hosting charge. Create a GitHub repository, upload index.html, enable Pages in repository Settings, then connect your domain using the DNS records shown by GitHub.
- Netlify also offers a free starter tier for static sites: create an account and deploy the folder by drag-and-drop, then connect a domain you own.
- Domain registration and renewal are normally paid separately. Compare current South African registrar pricing before purchasing.

This is a static starter website. It does not include a database, online payment system, secure quote portal or server-side contact form.

Branding assets:
- assets/bcsa-header-desktop.png: horizontal desktop website banner.
- assets/bcsa-header-mobile.png: vertical mobile banner.
The homepage automatically switches to the mobile artwork on screens 640px wide or narrower.
Keep the assets folder alongside index.html when uploading/publishing the website.
